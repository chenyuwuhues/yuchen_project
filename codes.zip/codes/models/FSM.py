import torch.nn as nn
import torch

'''
图像部分的通道范围是1~12, 水印部分的通道范围是13~24
'''
#
class FSM(nn.Module):
    def __init__(self, opt):
        super(FSM, self).__init__()
        #
        self.split1_img = opt['network']['InvBlock']['split1_img']  # 12
        self.strength_factor = 1  # 1

    def gauss_noise(self, shape):
        noise = torch.zeros(shape).cuda()  # 创建一个形状为 shape 的全零张量，并将其移到 GPU 上
        for i in range(noise.shape[0]):  # 通过循环遍历 noise 张量的第一个维度，这通常是批次大小（batch size）
            # 对于每个批次中的元素，使用 torch.randn() 生成一个具有相同形状的随机张量（符合标准正态分布），然后将其移到 GPU 上，并将其赋值给 noise 张量中对应的批次元素。
            noise[i] = torch.randn(noise[i].shape).cuda()

        return noise

    def forward(self, encoded_img, cover_down=None, rev=False):
        #
        if not rev:
            # 方法一（也就是文中未经改进的方法）：
            # return encoded_img[:, self.split1_img:, :, :] + encoded_img[:, :self.split1_img, :, :]

            # 方法二（其他文章用的方法）：
            # return encoded_img[:, :self.split1_img, :, :]

            # 方法三：
            # encoded_img的大小为B*24*64*64，msg表示从中选取通道为[13,24]的通道图像
            msg = encoded_img[:, self.split1_img:, :, :]
            # # cover_down是经过DWT变换的载体图像
            out = cover_down + self.strength_factor * msg   # (B, 12, 64, 64)
            return out

        else:            
            # msg copy
            # z = self.gauss_noise(encoded_img.shape)
            # out = torch.cat((encoded_img, z), dim=1)  # (B, 24, 64, 64)
            out = torch.cat((encoded_img, encoded_img), dim=1)  # (B, 24, 64, 64)
            return out

