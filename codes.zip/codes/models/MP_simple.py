import torch
import torch.nn as nn
import math
import numpy as np

class ConvTBNRelu(nn.Module):
    """
    A sequence of TConvolution, Batch Normalization, and ReLU activation
    转置卷积（TConvolution）、批量标准化（Batch Normalization）和 ReLU 激活函数。
    """

    def __init__(self, channels_in, channels_out, stride=2):
        super(ConvTBNRelu, self).__init__()

        self.layers = nn.Sequential(
            nn.ConvTranspose2d(channels_in, channels_out, kernel_size=2, stride=stride, padding=0),
            nn.BatchNorm2d(channels_out),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.layers(x)

# 假设UpConvt中ConvTBNRelu层的数量为n
# 那么一个H*W的张量通过该UpConvt时会增大2^n倍，也就是变成(2^n * H)*(2^n * W)
class UpConvt(nn.Module):
    '''
    Network that composed by layers of ConvTBNRelu
    UpConvt是由多个 ConvTBNRelu 层组成的网络
    '''

    # blocks 表示要添加的 ConvTBNRelu 层的数量
    def __init__(self, in_channels, out_channels, blocks):
        super(UpConvt, self).__init__()

        # 根据 blocks 参数的值决定是否添加一层起始的 ConvTBNRelu 层。
        # 如果 blocks 不为 0，则创建一个包含一层 ConvTBNRelu 的列表 layers，否则创建一个空列表。
        layers = [ConvTBNRelu(in_channels, out_channels)] if blocks != 0 else []
        for _ in range(blocks - 1):
            layer = ConvTBNRelu(out_channels, out_channels)
            layers.append(layer)

        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)

class ConvBNRelu(nn.Module):
    """
    A sequence of Convolution, Batch Normalization, and ReLU activation
    卷积（Convolution）、批量标准化（Batch Normalization）和 ReLU 激活函数。
    """

    def __init__(self, channels_in, channels_out, stride=2):
        super(ConvBNRelu, self).__init__()

        self.layers = nn.Sequential(
            nn.Conv2d(channels_in, channels_out, kernel_size=2, stride=stride, padding=0),
            nn.BatchNorm2d(channels_out),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.layers(x)

# 假设DownConv中ConvBNRelu层的数量为n
# 那么一个H*W的张量通过该DownConv时会缩小2^n倍，也就是变成(H/2^n)*(W/2^n)
class DownConv(nn.Module):
    '''
    Network that composed by layers of ConvBNRelu
    DownConv是由多个 ConvBNRelu 层组成的网络
    '''

    # blocks 表示要添加的 ConvBNRelu 层的数量
    def __init__(self, in_channels, out_channels, blocks):
        super(DownConv, self).__init__()

        # 根据 blocks 参数的值决定是否添加一层起始的 ConvBNRelu 层。
        # 如果 blocks 不为 0，则创建一个包含一层 ConvBNRelu 的列表 layers，否则创建一个空列表。
        layers = [ConvBNRelu(in_channels, out_channels)] if blocks != 0 else []
        for _ in range(blocks - 1):
            layer = ConvBNRelu(out_channels, out_channels)
            layers.append(layer)

        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)

class MP_simple(nn.Module):
    def __init__(self, opt):
        super(MP_simple, self).__init__()
        #
        self.opt = opt
        self.msg_length = opt['network']['message_length']  # 64/1024
        self.h, self.w = opt['network']['H'], opt['network']['W']   # (128,128)/(256,256)
        blocks = int(np.log2(self.h // int(np.sqrt(self.msg_length))))   # 4
        channels = 1  # 1
        self.split1_img = opt['network']['InvBlock']['split1_img']  # 12

        self.reshape_length = int(math.sqrt(self.msg_length)) # 8

        # 定义上采样层，作用是将(B, 1, 8, 8)变为(B, 1, 128, 128)
        self.UpConvt = UpConvt(channels, channels, blocks)

        # 定义下采样层，作用是将(B, 1, 128, 128)变为(B, 1, 8, 8)
        self.DownConv = DownConv(channels, channels, blocks)

    def forward(self, image, message, invDown, rev=False):
        if not rev:
            #
            message1 = message
            message2 = message
            message3 = message
            #
            shaped_message1 = torch.reshape(message1, (message1.size(0), 1, self.reshape_length, self.reshape_length))  # (B, 1, 8, 8)
            shaped_message2 = torch.reshape(message2, (message2.size(0), 1, self.reshape_length, self.reshape_length))
            shaped_message3 = torch.reshape(message3, (message3.size(0), 1, self.reshape_length, self.reshape_length))
            #
            expanded_message1 = self.UpConvt(shaped_message1)  # (B, 1, 8, 8)->(B, 1, 128, 128)
            expanded_message2 = self.UpConvt(shaped_message2)
            expanded_message3 = self.UpConvt(shaped_message3)
            #
            msg_concat = torch.cat([expanded_message1, expanded_message2, expanded_message3], dim=1)  # (B, 3, 128, 128)/(B, 3, 256, 256)
            msg_down = invDown(msg_concat)                                                            # (B, 12, 64, 64)/(B, 12, 128, 128)
            #
            concat = torch.cat([image, msg_down], dim=1)  # (B, 24, 64, 64)/(B, 24, 128, 128)

            return concat

        else:
            # image: (B, 24, 64, 64)/(B, 24, 128, 128)
            imgs = image[:, 0:self.split1_img, :, :]  # (B, 12, 64, 64)/(B, 12, 128, 128)
            msg = image[:, self.split1_img:, :, :]  # (B, 12, 64, 64)/(B, 12, 128, 128)
            msg = invDown(msg, rev=True)  # (B, 3, 128, 128)/(B, 3, 256, 256)

            # msg: (B, 3, 128, 128)
            msg1 = msg.narrow(1, 0, 1)
            msg2 = msg.narrow(1, 1, 1)
            msg3 = msg.narrow(1, 2, 1)
            #
            msg1 = self.DownConv(msg1)      # (B, 1, 128, 128)->(B, 1, 8, 8)
            msg2 = self.DownConv(msg2)
            msg3 = self.DownConv(msg3)
            #
            msg1 = torch.reshape(msg1, (msg1.size(0), msg1.size(2) * msg1.size(3)))   # (B, 1, 8, 8)->(B, 64)
            msg2 = torch.reshape(msg2, (msg2.size(0), msg2.size(2) * msg2.size(3)))
            msg3 = torch.reshape(msg3, (msg3.size(0), msg3.size(2) * msg3.size(3)))
            # msg ave pooling
            message_rev = torch.mean(torch.cat((msg1.unsqueeze(2), msg2.unsqueeze(2), msg3.unsqueeze(2)), dim=2), dim=2)

            return imgs, message_rev




