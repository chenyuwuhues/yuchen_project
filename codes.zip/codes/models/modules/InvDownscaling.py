from numpy import dtype
import torch
import torch.nn as nn
import torch.nn.functional as F


#
class InvDownscaling(nn.Module):
    def __init__(self, opt):
        super(InvDownscaling, self).__init__()
        self.down_opt = opt['network']['InvBlock']['downscaling']
        #
        self.in_nc = self.down_opt['in_nc']
        self.operations = nn.ModuleList()
        #
        if self.down_opt['type'] == 'haar':
            for i in range(self.down_opt['down_num']):
                b = HaarDownsampling(self.down_opt['current_cn'])
                self.operations.append(b)
                self.down_opt['current_cn'] = int(self.in_nc / self.down_opt['scale'] / self.down_opt['scale'])

    def forward(self, x, rev=False):
        if not rev:
            for op in self.operations:
                x = op.forward(x, rev)
        else:
            for op in reversed(self.operations):
                x = op.forward(x, rev)
        return x



# Haar 下采样是一种简单而有效的下采样方法，它使用固定的权重矩阵对输入图像进行滤波以进行下采样操作。
class HaarDownsampling(nn.Module):
    # 参数 channel_in 表示输入张量的通道数
    def __init__(self, channel_in):
        super(HaarDownsampling, self).__init__()
        self.channel_in = channel_in
        # 初始化一个形状为 (4, 1, 2, 2) 的张量 haar_weights，用于存储 Haar 下采样的权重（haar_weights就是一个权重矩阵）
        # 第一个维度（4）表示有 4 个滤波器，每个滤波器对应一个 Haar 下采样操作。
        # 第二个维度（1）表示每个滤波器只有一个输入通道。
        # 后两个维度（2, 2）表示每个滤波器的大小为 2x2。
        self.haar_weights = torch.ones(4, 1, 2, 2)

        # 对 haar_weights 中特定位置的值进行修改，以实现 Haar 下采样的效果
        self.haar_weights[1, 0, 0, 1] = -1  # 将第一个滤波器的右上角（坐标为0,1）元素设置为 -1，从而在 Haar 下采样中减去右上角的像素值。
        self.haar_weights[1, 0, 1, 1] = -1  # 将第一个滤波器的右下角（坐标为1,1）元素设置为 -1，也是进行减法操作。

        self.haar_weights[2, 0, 1, 0] = -1  # 设置了第二个滤波器的左下角元素为 -1，进行减法操作。
        self.haar_weights[2, 0, 1, 1] = -1

        self.haar_weights[3, 0, 1, 0] = -1  # 设置了第三个滤波器的左下角元素为 -1，进行减法操作。
        self.haar_weights[3, 0, 0, 1] = -1

        # 将 haar_weights 按照第一个维度（dim=0）进行复制，并沿着第一个维度进行连接，重复 self.channel_in 次。
        # 这样做的目的是将 Haar 下采样的权重矩阵扩展到与输入张量具有相同的通道数（因为前面的haar_weights通道数为1，因此乘上self.channel_in就能得到和输入张量一样的通道数）。
        self.haar_weights = torch.cat([self.haar_weights] * self.channel_in, 0)
        # 将 haar_weights 转换为可学习的模型参数，并将其存储为模型的一个参数。这样做的目的是使得 Haar 下采样的权重矩阵可以随着训练过程进行更新。
        self.haar_weights = nn.Parameter(self.haar_weights)
        # TODO：但是这里设置权重矩阵的梯度计算为False，即不随着训练梯度下降更新参数，似乎有矛盾？？？
        self.haar_weights.requires_grad = False

    def forward(self, x, rev=False):
        if not rev:
            out = F.conv2d(x, self.haar_weights, bias=None, stride=2, groups=self.channel_in) / 4.0
            out = out.reshape([x.shape[0], self.channel_in, 4, x.shape[2] // 2, x.shape[3] // 2])
            out = torch.transpose(out, 1, 2)

            out = out.reshape([x.shape[0], self.channel_in * 4, x.shape[2] // 2, x.shape[3] // 2])
            return out
        else:
            out = x.reshape([x.shape[0], 4, self.channel_in, x.shape[2], x.shape[3]])
            out = torch.transpose(out, 1, 2)
            out = out.reshape([x.shape[0], self.channel_in * 4, x.shape[2], x.shape[3]])
            return F.conv_transpose2d(out, self.haar_weights, bias=None, stride=2, groups = self.channel_in)

 


