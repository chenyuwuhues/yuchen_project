import torch
import torch.nn as nn
import torchvision
import codes.utils.utils as utils
import os
import numpy as np
import logging
import random
from codes.models.CIN import CIN
from codes.models.Discriminator import Discriminator
from codes.models.modules.loss import ReconstructionImgLoss, ReconstructionMsgLoss, EncodedLoss
import torch.optim.lr_scheduler as lr
import codes.utils.checkpoint as check
import kornia
from torchvision.transforms import functional as F
from PIL import Image
from torchvision import transforms



# ---------------------------------------------------------------------------------
class Network(nn.Module):
    def __init__(self, opt, device, path_in=None):
        super(Network, self).__init__()
        # 
        self.opt = opt
        self.device = device
        self.device_ids = opt['train']['device_ids']
        # init model
        self.cinNet = CIN(opt, self.device)
        # parallel
        self.cinNet = nn.DataParallel(self.cinNet, device_ids=self.device_ids)
        # loss
        self.RecImgLoss = ReconstructionImgLoss(opt)
        self.RecMsgLoss = ReconstructionMsgLoss(opt)
        self.encodedLoss = EncodedLoss(opt)
        # start_lr
        self.Lr_current = opt['lr']['start_lr']
        # optimizer
        if opt['lr']['optimizer'] == 'Adam':
            self.optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, self.cinNet.parameters()),
                                              lr=self.Lr_current)
        elif opt['lr']['optimizer'] == 'SGD':
            self.optimizer = torch.optim.SGD(filter(lambda p: p.requires_grad, self.cinNet.parameters()),
                                             lr=self.Lr_current, momentum=0.9)
        # lr scheduler
        self.lr_milestones = opt['lr']['milestones']
        self.lr_gamma = opt['lr']['gamma']
        self.scheduler = lr.MultiStepLR(self.optimizer, milestones=self.lr_milestones, gamma=self.lr_gamma)
        # step config
        self.current_step = 0
        # loss weight
        self.lw = utils.loss_lamd(self.current_step, opt)

        # 对抗网络鉴别器相关
        self.discriminator = Discriminator().to(self.device)
        self.discriminator = torch.nn.DataParallel(self.discriminator)
        # mark "cover" as 1, "encoded" as 0
        self.label_cover = torch.full((opt['train']['batch_size'], 1), 1, dtype=torch.float, device=device)
        self.label_encoded = torch.full((opt['train']['batch_size'], 1), 0, dtype=torch.float, device=device)
        self.optimizer_discriminator = torch.optim.Adam(self.discriminator.parameters(), lr=self.Lr_current)
        self.criterion_BCE = nn.BCEWithLogitsLoss().to(device)


        # init checkpoint，path_in['path_checkpoint']表示存放checkpoint模型的地址
        # 导入模型的时候必须用这个导入
        self.Checkpoint1 = check.Checkpoint(path_in['path_checkpoint'] + '/discriminator', opt)
        self.Checkpoint2 = check.Checkpoint(path_in['path_checkpoint'] + '/encoder_decoder', opt)
        # loading resume state if exists，如果存在已经训练好的模型，则加载
        if opt['train']['resume']['Empty'] != True:
            self.resume()

        # path
        self.img_w_folder_tra = path_in['img_w_folder_tra']  # 存放..图片
        self.loss_w_folder = path_in['loss_w_folder']
        self.log_folder = path_in['log_folder']
        self.img_w_folder_val = path_in['img_w_folder_val']
        self.img_w_folder_test = path_in['img_w_folder_test']
        self.time_now_NewExperiment = path_in['time_now_NewExperiment']

    def train(self, train_data, current_epoch):
        logging.info('--------------------------------------------------------\n')
        logging.info('##### train #####\n')
        self.current_epoch = current_epoch
        #
        with torch.enable_grad():
            # 鉴别器的每轮损失
            loss_per_epoch_d_cover = 0
            loss_per_epoch_d_encoded = 0
            # 编码器解码器的每轮损失
            loss_per_epoch_sum = 0
            loss_per_epoch_img = 0
            loss_per_epoch_msg = 0
            loss_per_epoch_enc = 0
            loss_per_epoch_high = 0
            loss_per_epoch_dis = 0
            train_step = 0
            for _, image in enumerate(train_data):
                #
                self.cinNet.train()
                self.discriminator.train()
                #
                image = image.to(self.device)
                # msg
                if self.opt['datasets']['msg']['mod_a']:  # msg in [0, 1]
                    message = torch.Tensor(np.random.choice([0, 1], (image.shape[0], self.opt['network']['message_length']))).to(self.device)
                elif self.opt['datasets']['msg']['mod_b']:  # msg in [-1, 1]
                    message = torch.Tensor(np.random.choice([0, 1], (image.shape[0], self.opt['network']['message_length']))).to(self.device)
                    message = message * 2 - 1
                else:
                    print('input message error, exit!')
                    exit()

                # fix noise-layer each batch
                if self.opt['noise']['option'] == 'Combined':
                    NoiseName = self.opt['noise']['Combined']['names']
                    weights = self.opt['noise']['Combined']['weights']
                    # 根据权重来进行随机选择。k=1 表示只选择一个元素。由于 random.choices 返回的是一个列表，所以使用 [0] 来获取选择的噪声
                    noise_choice = random.choices(NoiseName, weights=weights, k=1)[0]
                else:
                    noise_choice = self.opt['noise']['option']
                # cinNet
                # watermarking_img：水印图像
                # noised_img：噪声图像
                # img_fake：通过可逆模块生成的“恢复的载体图像”
                # msg_fake：通过可逆模块生成的“恢复的秘密信息”
                loss_high, watermarking_img, noised_img, img_fake, msg_fake = self.cinNet(image, message, noise_choice, True)

                '''
                train discriminator
                '''
                self.optimizer_discriminator.zero_grad()
                # RAW : target label for image should be "cover"(1)
                d_label_cover = self.discriminator(image)
                d_cover_loss = self.criterion_BCE(d_label_cover, self.label_cover[:d_label_cover.shape[0]])
                d_cover_loss.backward()

                # GAN : target label for encoded image should be "encoded"(0)
                d_label_encoded = self.discriminator(watermarking_img.detach())
                d_encoded_loss = self.criterion_BCE(d_label_encoded, self.label_encoded[:d_label_encoded.shape[0]])
                d_encoded_loss.backward()

                self.optimizer_discriminator.step()

                '''
                train encoder and decoder
                '''
                self.optimizer.zero_grad()
                # GAN : 编码器希望鉴别器不能分辨载体图像和水印图像，因此它的目的是让鉴别器将水印图像
                # target label for encoded image should be "cover"(0)   TODO：这里是不是应该是"cover"(1)？？？
                g_label_decoded = self.discriminator(watermarking_img)

                # loss
                loss_dis = self.criterion_BCE(g_label_decoded, self.label_cover[:g_label_decoded.shape[0]])
                loss_RecImg = self.RecImgLoss(image, img_fake)
                loss_RecMsg = utils.func_loss_RecMsg(self.RecMsgLoss, message, msg_fake)
                loss_encoded = self.encodedLoss(image, watermarking_img)
                # 高频小波损失
                loss_high = loss_high

                # total loss
                train_loss = utils.func_loss(self.lw, loss_RecImg, loss_encoded, loss_RecMsg, loss_high, loss_dis)
                train_loss.backward()
                self.optimizer.step()

                # log print
                if self.current_step % self.opt['train']['logs_per_step'] == 0:
                    psnr_wm2co, psnr_no2co, psnr_rec2co, psnr_wm2no, ssim_wm2co, ssim_rec2co, acc, BitWise_AvgErr = self.psnr_ssim_acc(image, watermarking_img, noised_img, img_fake, msg_fake, message)
                    #
                    # BitWise_AvgErr1表示经过可逆模块提取出来的水印信息msg_fake_1与原始水印信息message之间的差距
                    # BitWise_AvgErr2表示经过不可逆模块提取出来的水印信息msg_fake_2与原始水印信息message之间的差距
                    utils.log_info(self.lw, self.current_epoch, self.opt['train']['epoch'], self.current_step,
                                   self.Lr_current, psnr_wm2co, psnr_no2co, psnr_rec2co, psnr_wm2no, \
                                   ssim_wm2co, ssim_rec2co, BitWise_AvgErr, d_cover_loss, d_encoded_loss,
                                   train_loss, loss_RecImg, loss_RecMsg, loss_encoded, loss_high, loss_dis, noise_choice)

                # save images
                if self.current_step % self.opt["train"]['saveTrainImgs_per_step'] == 0:
                    utils.mkdir(self.img_w_folder_tra)
                    # 保存的图片第一行是原始图像、第二行是水印图像、第三行是噪声图像、第四行是原始图像和水印图像的残差图、第五行是水印图像和噪声图像的残差图
                    utils.save_images(image, watermarking_img, noised_img, img_fake, self.current_epoch,
                                      self.current_step, self.img_w_folder_tra, self.time_now_NewExperiment, self.opt,
                                      resize_to=None)

                # break code if 'nan'
                if torch.isnan(train_loss):
                    logging.info("Invalid loss <nan>, break code !")
                    exit()

                # step update
                self.current_step += 1
                train_step += 1
                loss_per_epoch_d_cover = loss_per_epoch_d_cover + d_cover_loss.item()
                loss_per_epoch_d_encoded = loss_per_epoch_d_encoded + d_encoded_loss.item()

                loss_per_epoch_sum = loss_per_epoch_sum + (loss_RecImg.item() + loss_RecMsg.item() + loss_encoded.item() + loss_high.item() + loss_dis.item())
                loss_per_epoch_img = loss_per_epoch_img + loss_RecImg.item()
                loss_per_epoch_msg = loss_per_epoch_msg + loss_RecMsg.item()
                loss_per_epoch_enc = loss_per_epoch_enc + loss_encoded.item()
                loss_per_epoch_high = loss_per_epoch_high + loss_high.item()

                # loss weight update
                self.lw = utils.loss_lamd(self.current_step, self.opt)

                # lr update
                self.scheduler.step()
                self.Lr_current = self.scheduler.get_last_lr()[0]

            # Checkpoint
            if self.current_epoch % self.opt['train']['checkpoint_per_epoch'] == 0:
                logging.info('Checkpoint: Saving ganNet&cinNets and training states.')
                self.Checkpoint1.save(self.discriminator, self.current_step, self.current_epoch, 'discriminator')
                self.Checkpoint2.save(self.cinNet, self.current_step, self.current_epoch, 'cinNet')

            # write losses
            utils.mkdir(self.loss_w_folder)
            utils.write_losses(os.path.join(self.loss_w_folder, 'train-{}.txt'.format(self.time_now_NewExperiment)),
                               self.current_epoch,
                               loss_per_epoch_d_cover / train_step, loss_per_epoch_d_encoded / train_step,
                               loss_per_epoch_sum / train_step,
                               loss_per_epoch_msg / train_step, loss_per_epoch_enc / train_step, loss_per_epoch_high / train_step, loss_per_epoch_dis / train_step)

    def validation(self, val_data, current_epoch):
        #
        logging.info('--------------------------------------------------------\n')
        logging.info('##### validation #####\n')
        self.current_epoch = current_epoch
        #
        val_step = 0
        psnr_wm2no_mean = 0
        psnr_wm2co_mean = 0
        psnr_rec2co_mean = 0
        psnr_no2co_mean = 0
        BitWise_AvgErr_mean = 0
        ssim_wm2co_mean = 0
        ssim_rec2co_mean = 0

        # 鉴别器的验证损失
        loss_per_val_d_cover = 0
        loss_per_val_d_endcoded = 0
        # 编码器解码器的验证损失
        loss_per_val_sum = 0
        loss_per_val_img = 0
        loss_per_val_msg = 0
        loss_per_val_enc = 0
        loss_per_val_high = 0
        loss_per_val_dis = 0
        #
        with torch.no_grad():
            # 
            for _, image in enumerate(val_data):  # torch.utils.data.Dataset
                #
                self.cinNet.eval()
                image = image.to(self.device)
                # msg
                if self.opt['datasets']['msg']['mod_a']:  # msg in [0, 1]
                    message = torch.Tensor(
                        np.random.choice([0, 1], (image.shape[0], self.opt['network']['message_length']))).to(self.device)
                elif self.opt['datasets']['msg']['mod_b']:  # msg in [-1, 1]
                    message = torch.Tensor(
                        np.random.choice([0, 1], (image.shape[0], self.opt['network']['message_length']))).to(self.device)
                    message = message * 2 - 1
                else:
                    print('input message error, exit!')
                    exit()

                # fix noise-layer each batch
                if self.opt['noise']['option'] == 'Combined':
                    NoiseName = self.opt['noise']['Combined']['names']
                    weights = self.opt['noise']['Combined']['weights']
                    # 根据权重来进行随机选择。k=1 表示只选择一个元素。由于 random.choices 返回的是一个列表，所以使用 [0] 来获取选择的噪声
                    noise_choice = random.choices(NoiseName, weights=weights, k=1)[0]
                else:
                    noise_choice = self.opt['noise']['option']

                # cinNet
                loss_high, watermarking_img, noised_img, img_fake, msg_fake = \
                    self.cinNet(image, message, noise_choice, True)

                '''
                validate discriminator
                '''
                # RAW : target label for image should be "cover"(1)
                d_label_cover = self.discriminator(image)
                d_cover_loss = self.criterion_BCE(d_label_cover, self.label_cover[:d_label_cover.shape[0]])

                # GAN : target label for encoded image should be "encoded"(0)
                d_label_encoded = self.discriminator(watermarking_img.detach())
                d_encoded_loss = self.criterion_BCE(d_label_encoded, self.label_encoded[:d_label_encoded.shape[0]])

                '''
                validate encoder and decoder
                '''
                # GAN : 编码器希望鉴别器不能分辨载体图像和水印图像，因此它的目的是让鉴别器将水印图像
                # target label for encoded image should be "cover"(0)   TODO：这里是不是应该是"cover"(1)？？？
                g_label_decoded = self.discriminator(watermarking_img)

                # loss
                loss_dis = self.criterion_BCE(g_label_decoded, self.label_cover[:g_label_decoded.shape[0]])
                loss_RecImg = self.RecImgLoss(image, img_fake)
                loss_RecMsg = utils.func_loss_RecMsg(self.RecMsgLoss, message, msg_fake)
                loss_encoded = self.encodedLoss(image, watermarking_img)
                loss_high = loss_high
                val_loss = loss_RecImg + loss_RecMsg + loss_encoded + loss_high + loss_dis

                # log print
                if val_step % self.opt['train']['val']['logs_per_step'] == 0:
                    psnr_wm2co, psnr_no2co, psnr_rec2co, psnr_wm2no, ssim_wm2co, ssim_rec2co, acc, BitWise_AvgErr = self.psnr_ssim_acc(image, watermarking_img, noised_img, img_fake, msg_fake, message)
                    #
                    utils.log_info(self.lw, self.current_epoch, 0, self.current_step,
                                   self.Lr_current, psnr_wm2co, psnr_no2co, psnr_rec2co, psnr_wm2no,
                                   ssim_wm2co, ssim_rec2co, BitWise_AvgErr, d_cover_loss, d_encoded_loss,
                                   val_loss, loss_RecImg, loss_RecMsg, loss_encoded, loss_high, loss_dis,
                                   noise_choice)

                # save images
                if val_step == self.opt["train"]['saveValImgs_in_step']:
                    utils.mkdir(self.img_w_folder_val)
                    utils.save_images(image, watermarking_img, noised_img, img_fake, self.current_epoch,
                                      self.current_step, self.img_w_folder_val, self.time_now_NewExperiment, self.opt,
                                      resize_to=None)

                # loss write
                val_step += 1
                loss_per_val_d_cover = loss_per_val_d_cover + d_cover_loss.item()
                loss_per_val_d_endcoded = loss_per_val_d_endcoded + d_encoded_loss.item()

                loss_per_val_sum = loss_per_val_sum + (loss_RecImg.item() + loss_RecMsg.item() + loss_encoded.item() + loss_high.item() + loss_dis.item())
                loss_per_val_img = loss_per_val_img + loss_RecImg.item()
                loss_per_val_msg = loss_per_val_msg + loss_RecMsg.item()
                loss_per_val_enc = loss_per_val_enc + loss_encoded.item()
                loss_per_val_high = loss_per_val_high + loss_high.item()
                loss_per_val_dis = loss_per_val_dis + loss_dis.item()

                # mean
                psnr_wm2no_mean = psnr_wm2no_mean + psnr_wm2no.item()
                psnr_wm2co_mean = psnr_wm2co_mean + psnr_wm2co.item()
                psnr_rec2co_mean = psnr_rec2co_mean + psnr_rec2co.item()
                psnr_no2co_mean = psnr_no2co_mean + psnr_no2co.item()
                #
                ssim_wm2co_mean = ssim_wm2co_mean + ssim_wm2co.item()
                ssim_rec2co_mean = ssim_rec2co_mean + ssim_rec2co.item()

                #
                BitWise_AvgErr_mean = utils.func_mean_filter_None(BitWise_AvgErr_mean, BitWise_AvgErr, 'add')

            # logging mean psnr
            print_BitWise_AvgErr_mean = utils.func_mean_filter_None(BitWise_AvgErr_mean, val_step, 'div')

            # logging mean 
            logging.info('\npsnr_no2co_mean = {}\n\
                            psnr_rec2co_mean = {}\n\
                            psnr_wm2no_mean = {}\n\
                            psnr_wm2co_mean = {}\n \
                            #------------------------\n\
                            BitWise_AvgErr = {}\n\
                            ------------------------\n\
                            ssim_wm2co_mean = {}\n\
                            ssim_rec2co_mean = {}' \
                         .format(psnr_no2co_mean / val_step, \
                                 psnr_rec2co_mean / val_step, \
                                 psnr_wm2no_mean / val_step, \
                                 psnr_wm2co_mean / val_step, \
                                 # ------------------------
                                 print_BitWise_AvgErr_mean, \
                                 # ------------------------
                                 ssim_wm2co_mean / val_step, \
                                 ssim_rec2co_mean / val_step))

            #
            utils.mkdir(self.loss_w_folder)
            utils.write_losses(os.path.join(self.loss_w_folder, 'val-{}.txt'.format(self.time_now_NewExperiment)),
                               self.current_epoch,
                               loss_per_val_d_cover / val_step, loss_per_val_d_endcoded / val_step,
                               loss_per_val_sum / val_step,
                               loss_per_val_msg / val_step, loss_per_val_enc / val_step, loss_per_val_high / val_step, loss_per_val_dis / val_step)
        #
        logging.info('--------------------------------------------------------\n')

    def test(self, test_data, current_epoch):
        #
        logging.info('--------------------------------------------------------\n')
        logging.info('##### test only #####\n')
        self.current_epoch = current_epoch
        #
        with torch.no_grad():
            #
            self.cinNet.eval()
            test_step = 0
            total_steps = len(test_data)
            #
            psnr_wm2no_mean = 0
            psnr_wm2co_mean = 0
            psnr_rec2co_mean = 0
            psnr_no2co_mean = 0
            BER_mean = 0
            ssim_wm2co_mean = 0
            ssim_rec2co_mean = 0
            # 
            for _, image in enumerate(test_data):
                #
                if (test_step * self.opt['train']['batch_size']) >= self.opt['datasets']['test']['num']:
                    break
                #
                image = image.to(self.device)

                # msg
                if self.opt['datasets']['msg']['mod_a']:  # msg in [0, 1]
                    message = torch.Tensor(
                        np.random.choice([0, 1], (image.shape[0], self.opt['network']['message_length']))).to(self.device)
                elif self.opt['datasets']['msg']['mod_b']:  # msg in [-1, 1]
                    message = torch.Tensor(
                        np.random.choice([0, 1], (image.shape[0], self.opt['network']['message_length']))).to(self.device)
                    message = message * 2 - 1
                else:
                    print('input message error, exit!')
                    exit()

                # fix noise-layer each batch
                if self.opt['noise']['option'] == 'Combined':
                    NoiseName = self.opt['noise']['Combined']['names']
                    weights = self.opt['noise']['Combined']['weights']
                    # 根据权重来进行随机选择。k=1 表示只选择一个元素。由于 random.choices 返回的是一个列表，所以使用 [0] 来获取选择的噪声
                    noise_choice = random.choices(NoiseName, weights=weights, k=1)[0]
                else:
                    noise_choice = self.opt['noise']['option']

                # cinNet
                loss_high, watermarking_img, noised_img, img_fake, msg_fake = \
                    self.cinNet(image, message, noise_choice, False)
                # psnr ssim acc
                psnr_wm2co, psnr_no2co, psnr_rec2co, psnr_wm2no, ssim_wm2co, ssim_rec2co, acc, BitWise_AvgErr = self.psnr_ssim_acc(image, watermarking_img, noised_img, img_fake, msg_fake, message)

                # mean
                psnr_wm2no_mean = psnr_wm2no_mean + psnr_wm2no
                psnr_wm2co_mean = psnr_wm2co_mean + psnr_wm2co
                psnr_rec2co_mean = psnr_rec2co_mean + psnr_rec2co
                psnr_no2co_mean = psnr_no2co_mean + psnr_no2co
                #
                ssim_wm2co_mean = ssim_wm2co.item() + ssim_wm2co_mean
                ssim_rec2co_mean = ssim_rec2co.item() + ssim_rec2co_mean
                #
                _, ber = utils.bitWise_accurary(msg_fake, message, self.opt)
                BER_mean = BER_mean + ber

                # loggging
                if test_step % self.opt["train"]['logTest_per_step'] == 0:
                    utils.log_info_test(test_step, total_steps, self.Lr_current, psnr_wm2co, psnr_no2co, psnr_rec2co,
                                        psnr_wm2no, ssim_wm2co, ssim_rec2co, BitWise_AvgErr, noise_choice)

                # save images
                if test_step % self.opt["train"]['saveTestImgs_per_step'] == 0:
                    utils.mkdir(self.img_w_folder_test)
                    utils.save_images(image, watermarking_img, noised_img, img_fake, self.current_epoch, test_step,
                                      self.img_w_folder_test, self.time_now_NewExperiment, self.opt, resize_to=None)
                #
                test_step += 1

            # logging mean 
            logging.info('\n\
                            psnr_no2co_mean = {}\n\
                            psnr_rec2co_mean = {}\n\
                            psnr_wm2no_mean = {}\n\
                            psnr_wm2co_mean = {}\n \
                            ------------------------\n\
                            BER_ave = {}\n\
                            ACC_ave = {}\n\
                            ------------------------\n\
                            ssim_wm2co_mean = {}\n\
                            ssim_rec2co_mean = {}' \
                         .format(psnr_no2co_mean.item() / test_step, \
                                 psnr_rec2co_mean.item() / test_step, \
                                 psnr_wm2no_mean.item() / test_step, \
                                 psnr_wm2co_mean.item() / test_step, \
                                 # ------------------------
                                 BER_mean / test_step, \
                                 (1 - BER_mean / test_step) * 100, \
                                 # ------------------------
                                 ssim_wm2co_mean / test_step, \
                                 ssim_rec2co_mean / test_step))
        # test 1 epoch
        logging.info('--------------------------------------------------------\n')
        logging.info('Test end !')

    def testOne(self, device):
        #
        logging.info('--------------------------------------------------------\n')
        logging.info('##### Test one #####\n')
        #
        with torch.no_grad():
            #
            self.cinNet.eval()
            #
            image_path = './selfTest/testImages/img7.jpg'
            image = Image.open(image_path)
            input_transforms = transforms.Compose([
                # transforms.CenterCrop((128, 128)),
                # transforms.Lambda(lambda img: F.crop(img, top=200, left=410, height=128, width=128)),
                # transforms.Lambda(lambda img: F.crop(img, top=20, left=50, height=128, width=128)),
                transforms.Resize([256, 256]),
                transforms.ToTensor(),
                transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
            ])
            image = image.convert('RGB')
            image = input_transforms(image).unsqueeze(0).to(device)

            # msg
            message = torch.Tensor(np.random.choice([0, 1], (image.shape[0], self.opt['network']['message_length']))).to(self.device)
            logging.info("Original watermark: \n")
            logging.info(message)

            # fix noise-layer each batch
            noise_choice = 'Identity'

            # cinNet
            loss_high, watermarking_img, noised_img, img_fake, msg_fake = \
                self.cinNet(image, message, noise_choice, False)

            logging.info("Recovered watermarked: \n")
            logging.info(msg_fake)
            # psnr ssim acc
            psnr_wm2co, psnr_no2co, psnr_rec2co, psnr_wm2no, ssim_wm2co, ssim_rec2co, acc, BitWise_AvgErr = self.psnr_ssim_acc(image, watermarking_img, noised_img, img_fake, msg_fake, message)

            logging.info(f"PSNR: {psnr_wm2co:.3f}")
            logging.info(f"SSIM: {ssim_wm2co:.3f}")
            logging.info(f"Acc: {acc:.3f}")

            utils.save_images_Identity(image, watermarking_img)

    def psnr_ssim_acc(self, image, watermarking_img, noised_img, img_fake, msg_fake, message):
        # psnr
        psnr_wm2co = kornia.metrics.psnr(
            ((image + 1) / 2).clamp(0, 1),
            ((watermarking_img.detach() + 1) / 2).clamp(0, 1),
            1,
        )
        psnr_no2co = kornia.metrics.psnr(
            ((image + 1) / 2).clamp(0, 1),
            ((noised_img.detach() + 1) / 2).clamp(0, 1),
            1,
        )
        psnr_rec2co = kornia.metrics.psnr(
            ((image + 1) / 2).clamp(0, 1),
            ((img_fake.detach() + 1) / 2).clamp(0, 1),
            1,
        )
        psnr_wm2no = kornia.metrics.psnr(
            ((image + 1) / 2).clamp(0, 1),
            ((noised_img.detach() + 1) / 2).clamp(0, 1),
            1,
        )
        # ssim
        ssim_wm2co = kornia.metrics.ssim(
            ((image + 1) / 2).clamp(0, 1),
            ((watermarking_img.detach() + 1) / 2).clamp(0, 1),
            window_size=11,
        ).mean()
        ssim_rec2co = kornia.metrics.ssim(
            ((image + 1) / 2).clamp(0, 1),
            ((img_fake.detach() + 1) / 2).clamp(0, 1),
            window_size=11,
        ).mean()
        # acc
        acc, BitWise_AvgErr = utils.bitWise_accurary(msg_fake, message, self.opt)
        return psnr_wm2co, psnr_no2co, psnr_rec2co, psnr_wm2no, ssim_wm2co, ssim_rec2co, acc, BitWise_AvgErr

    def resume(self):
        # resuming: all param loaded into default GPU
        # 恢复：所有参数都加载到默认 GPU 中
        device_id = torch.cuda.current_device()
        # 所有模型一起恢复
        if self.opt['train']['resume']['one_pth']:
            # 载入判别器
            resume_state_dis = torch.load(self.opt['path']['resume_state_discriminator_pth'],
                                      map_location=lambda storage, loc: storage.cuda(device_id))
            self.discriminator = self.Checkpoint1.resume_training(self.discriminator, 'discriminator', resume_state_dis)

            # 载入主干网络
            resume_state_main = torch.load(self.opt['path']['resume_state_main_pth'],
                                      map_location=lambda storage, loc: storage.cuda(device_id))
            self.cinNet = self.Checkpoint2.resume_training(self.cinNet, 'cinNet', resume_state_main)


        # else:# 不同模型单独恢复
        #     # resume CIN.IM and CIN.NIAM
        #     resume_state = torch.load(self.opt['path']['resume_state_cinNet'],
        #                               map_location=lambda storage, loc: storage.cuda(device_id))
        #     self.cinNet = self.Checkpoint.resume_training(self.cinNet, 'model_state_dict', resume_state)
        #     # resume CIN.NSM
        #     resume_state_nsmNet = torch.load(self.opt['path']['resume_state_nsmNet'],
        #                                      map_location=lambda storage, loc: storage.cuda(device_id))
        #     self.cinNet.module.nsm_model = self.Checkpoint.resume_training(self.cinNet.module.nsm_model, 'nsmNet',
        #                                                                    resume_state_nsmNet)
