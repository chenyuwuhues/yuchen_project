import torch
import torch.nn as nn


# TODO：该代码可以优化，这里每次都是2倍上采样或者2倍下采样，需要执行多次，
#  其实在调用的时候可以直接算出需要变化多少倍，那么就能直接指定scale_factor的大小，而不用堆叠这么多个

# TODO:借鉴博客https://blog.csdn.net/qq_41573860/article/details/117474254?utm_medium=distribute.pc_relevant.none-task-blog-2~default~baidujs_baidulandingword~default-4-117474254-blog-84975282.235^v43^pc_blog_bottom_relevance_base9&spm=1001.2101.3001.4242.3&utm_relevant_index=7，
#  官方github链接为https://github.com/leftthomas/ESPCN/blob/master/model.py，
#  但是这两者都是对单通道进行处理，目前不知道改成3通道效果好不好
class SubPixelConv(nn.Module):
    def __init__(self, in_channels, out_channels, scale_factor=2):
        super(SubPixelConv, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels * (scale_factor ** 2), kernel_size=1)

        # 指定卷积核的初始数值以及偏置值就能保证每次上采样得到的图像一样

        self.pixel_shuffle = nn.PixelShuffle(scale_factor)

    def forward(self, x):
        # 使用卷积操作将输入的通道数扩展到 out_channels * (scale_factor**2)
        x = self.conv(x)
        # 使用 PixelShuffle 重排通道到空间维度
        x = self.pixel_shuffle(x)
        return x

class SubPixelConv_rev(nn.Module):
    def __init__(self, in_channels, out_channels, downscale_factor=2):
        super(SubPixelConv_rev, self).__init__()
        self.conv = nn.Conv2d(in_channels * (downscale_factor ** 2), out_channels, kernel_size=1)
        self.pixel_unshuffle = nn.PixelUnshuffle(downscale_factor)

    def forward(self, x):
        # 先使用pixel_unshuffle对H和W进行减半，并且通道数增加4倍
        x = self.pixel_unshuffle(x)
        # 然后将通道数变成原来的数量
        x = self.conv(x)
        return x

class ExpandNet(nn.Module):
    '''
    	Network that composed by layers of SubPixelConv or SubPixelConv_rev
    '''

    def __init__(self, in_channels, out_channels, blocks):
        super(ExpandNet, self).__init__()
        # 上采样
        layers_up = [SubPixelConv(in_channels, out_channels)] if blocks != 0 else []
        for _ in range(blocks - 1):
            layer = SubPixelConv(in_channels, out_channels)
            layers_up.append(layer)

        self.layers_up = nn.Sequential(*layers_up)

        # 下采样
        layers_down = [SubPixelConv_rev(in_channels, out_channels)] if blocks != 0 else []
        for _ in range(blocks - 1):
            layer = SubPixelConv_rev(in_channels, out_channels)
            layers_down.append(layer)

        self.layers_down = nn.Sequential(*layers_down)

    def forward(self, x, rev=False):
        if not rev:
            return self.layers_up(x)
        else:
            return self.layers_down(x)