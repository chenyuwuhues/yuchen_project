import torch
import torch.nn as nn
from codes.models.modules.DenseBlock import DenseBlock


class InvArch(nn.Module):
    def __init__(self, split_len1, split_len2, clamp=1.0):
        super(InvArch, self).__init__()
        self.split_len1 = split_len1
        self.split_len2 = split_len2
        self.clamp = clamp

        self.F = DenseBlock(self.split_len2, self.split_len1)
        self.G = DenseBlock(self.split_len1, self.split_len2)
        self.H = DenseBlock(self.split_len1, self.split_len2)

    def e(self, s):
        return torch.exp(self.clamp * 2 * (torch.sigmoid(s) - 0.5))
            
    def forward(self, x, rev=False):
        '''
        param {x1} : image
        param {x2} : msg
        '''
        x1, x2 = (x.narrow(1, 0, self.split_len1), x.narrow(1, self.split_len1, self.split_len2))

        if not rev:
            # y1 = x1 + self.F(x2)
            # self.s = self.clamp * (torch.sigmoid(self.H(y1)) * 2 - 1)
            # y2 = x2.mul(torch.exp(self.s)) + self.G(y1)
            t2 = self.F(x2)
            y1 = x1 + t2
            s1, t1 = self.H(y1), self.G(y1)
            y2 = self.e(s1) * x2 + t1
        else:
            # self.s = self.clamp * (torch.sigmoid(self.H(x1)) * 2 - 1)
            # y2 = (x2 - self.G(x1)).div(torch.exp(self.s))
            # y1 = x1 - self.F(y2)
            s1, t1 = self.H(x1), self.G(x1)
            y2 = (x2 - t1) / self.e(s1)
            t2 = self.F(y2)
            y1 = (x1 - t2)

        return torch.cat((y1, y2), 1)
