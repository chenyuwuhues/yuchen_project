import torch.nn as nn
import torch
from codes.models.modules.InvArch import InvArch
from codes.models.modules.Conv1x1 import InvertibleConv1x1



class IM(nn.Module):
    def __init__(self, opt):
        super(IM, self).__init__()
        #
        self.operations = nn.ModuleList()
        # for _ in range(opt['network']['InvBlock']['block_num']):
        #     #
        #     # 这个结构是1×1卷积
        #     # 12+12
        #     a = InvertibleConv1x1(opt['network']['InvBlock']['split1_img'] + opt['network']['InvBlock']['split2_repeat'])
        #     self.operations.append(a)
        #
        for _ in range(opt['network']['InvBlock']['block_num']):
            #
            # 这个结构是Real NVP里面的
            # 12, 12
            b = InvArch(opt['network']['InvBlock']['split1_img'], opt['network']['InvBlock']['split2_repeat'])
            self.operations.append(b)



    def forward(self, x, rev=False):
        if not rev:
            #
            for op in self.operations:
                x = op.forward(x, rev)
                # x = shuffle_channels(x)
            #
        else:
            for op in reversed(self.operations):
                x = op.forward(x, rev)
                # x = shuffle_channels(x)
        return x

"""
    随机打乱输入张量 x 的通道轴。
    x: 输入张量，形状为 (B, C, H, W)
    返回：打乱通道后的张量，形状为 (B, C, H, W)
"""
def shuffle_channels(x):
    B, C, H, W = x.shape
    indices = torch.randperm(C)  # 生成随机排列的索引
    # print(indices)
    return x[:, indices, :, :]
    