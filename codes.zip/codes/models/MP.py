import torch
import torch.nn as nn
import math
import numpy as np
from codes.models.modules.ExpandNet import ExpandNet
from codes.models.modules.ConvNet import ConvBNRelu
from codes.models.modules.SENet import SENet

class MP(nn.Module):
    def __init__(self, opt):
        super(MP, self).__init__()
        #
        self.opt = opt
        self.msg_length = opt['network']['message_length']  # 64/1024
        self.h, self.w = opt['network']['H'], opt['network']['W']   # (128,128)/(256,256)
        self.blocks = 4
        self.channels = 64

        self.split1_img = opt['network']['InvBlock']['split1_img']  # 12
        self.repeat_num = opt['network']['InvBlock']['split2_repeat']  # 12

        message_expandNet_blocks = int(np.log2(self.h // int(np.sqrt(self.msg_length))))  #
        message_se_blocks = max(self.blocks - message_expandNet_blocks, 1)

        # 定义正向过程所需组件
        self.forward_layer1 = nn.Sequential(
            ConvBNRelu(1, self.channels),
            ExpandNet(self.channels, self.channels, blocks=message_expandNet_blocks),
            SENet(self.channels, self.channels, blocks=message_se_blocks),
        )
        self.forward_layer2 = SENet(self.channels, self.channels, blocks=self.blocks)
        self.forward_layer3 = nn.Conv2d(self.channels, 3, kernel_size=1)

        # 定义反向过程所需组件
        self.backward_layer1 = nn.Conv2d(3, self.channels, kernel_size=1)
        self.backward_layer2 = ExpandNet(self.channels, self.channels, blocks=message_expandNet_blocks)
        self.backward_layer3 = SENet(self.channels, self.channels, blocks=message_se_blocks)
        self.backward_layer4 = ConvBNRelu(self.channels, 1)


    def forward(self, image, message, invDown, rev=False):
        if not rev:
            # reshape操作，将一维秘密信息转换成二维秘密信息
            size = int(np.sqrt(message.shape[1]))
            msg_image = message.view(-1, 1, size, size)             # (B, 1, 8, 8)/(B, 1, 32, 32)

            # 经过一个ConvBNRelu层、
            # message_convT_blocks个ExpandNet层、
            # message_se_blocks个SENet层
            msg_up = self.forward_layer1(msg_image)             # (B, 64, 128, 128)/(B, 64, 256, 256)
            msg_features = self.forward_layer2(msg_up)          # (B, 64, 128, 128)/(B, 64, 256, 256)
            msg_features = self.forward_layer3(msg_features)    # (B, 3, 128, 128)/(B, 3, 256, 256)
            msg_down = invDown(msg_features)                    # (B, 12, 64, 64)/(B, 12, 128, 128)

            #
            concat = torch.cat([image, msg_down], dim=1)        # (B, 24, 64, 64)/(B, 24, 128, 128)

            return concat

        else:
            # image: (B, 24, 64, 64)/(B, 24, 128, 128)
            imgs = image[:, 0:self.split1_img, :, :]        # (B, 12, 64, 64)/(B, 12, 128, 128)
            msg = image[:, self.split1_img:, :, :]          # (B, 12, 64, 64)/(B, 12, 128, 128)
            msg = invDown(msg, rev=True)                    # (B, 3, 128, 128)/(B, 3, 256, 256)

            message_rev = self.backward_layer1(msg)        # (B, 64, 128, 128)/(B, 64, 256, 256)
            message_rev = self.backward_layer2(message_rev, rev=True)       # (B, 64, 8, 8)/(B, 64, 32, 32)
            message_rev = self.backward_layer3(message_rev)                 # (B, 64, 8, 8)/(B, 64, 32, 32)
            message_rev = self.backward_layer4(message_rev)                 # (B, 1, 8, 8)/(B, 1, 32, 32)
            message_rev = message_rev.view(message_rev.shape[0], -1)        # (B, 64)/(B, 1024)

            return imgs, message_rev