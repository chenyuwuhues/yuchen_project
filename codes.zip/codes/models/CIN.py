from codes.models.IM import IM
from codes.models.Noise_pool import Noise_pool
from codes.models.FSM import FSM
from codes.models.modules.DWT_IWT import DWT_IWT
from codes.models.MP import MP
from codes.models.MP_simple import MP_simple
from codes.models.IEM import IEM
from codes.models.NSM import NSM
from codes.models.modules.loss import *
from codes.utils.utils import load


# ---------------------------------------------------------------------------------
class CINBasic(nn.Module):
    def __init__(self, opt, device):
        super(CINBasic, self).__init__()
        # 
        self.opt = opt
        self.device = device
        self.h, self.w = opt['network']['H'], opt['network']['W']
        self.msg_length = opt['network']['message_length']
        #
        self.fusion_model = MP(opt).to(device)
        # self.fusion_model = MP_simple(opt).to(device)
        self.invertible_model = IM(opt).to(device)
        self.cs_model = FSM(opt).to(device)
        self.noise_model = Noise_pool(opt, device).to(device)
        self.enhance_model = IEM(opt, device).to(device)
        if opt['network']['InvBlock']['downscaling']['use_down']:
            self.invDown = DWT_IWT().to(device)
        # 高频小波损失
        self.highLoss = HighLoss(opt)

        # 加载预训练好的NSM模型
        # nsm_path = '../pth/NSM_0580.pt'
        # self.nsm_model = NSM(opt, self.device)
        # load(nsm_path, self.nsm_model)
        # self.nsm_model.eval()

    def encoder(self, image, msg):
        # down                                             # image: (B, 3, 128, 128)/(B, 3, 256, 256)
        # TODO：这里为什么要进行下采样
        # 解答：这里的下采样就是DWT变换，目的是让进入IM模块的载体图像和水印都经过DWT变换
        cover_down = self.invDown(image)                # (B, 12, 64, 64)/(B, 12, 128, 128)
        # fusion
        fusion = self.fusion_model(cover_down, msg, self.invDown)          # (B, 24, 64, 64)/(B, 24, 128, 128)
        # inv_forward
        inv_encoded = self.invertible_model(fusion)    # (B, 24, 64, 64)/(B, 24, 128, 128)
        # cs
        cs = self.cs_model(inv_encoded, cover_down)    # (B, 12, 64, 64)/(B, 12, 128, 128)

        # 计算高频小波损失，通道数为12，那么后9个通道包含的就是高频信息
        cover_high = cover_down.narrow(1, 3, 9)
        watermarking_high = cs.narrow(1, 3, 9)
        loss_high = self.highLoss(cover_high, watermarking_high)

        # up to out
        watermarking_img = self.invDown(cs, rev=True).clamp(-1, 1)   # (B, 3, 128, 128)/(B, 3, 256, 256)

        return watermarking_img, loss_high

    def noise_pool(self, watermarking_img, image, noise_choice):
        # noise
        noised_img = self.noise_model(watermarking_img, image, noise_choice)    # (B, 3, 128, 128)/(B, 3, 256, 256)
        
        return noised_img

    # def nsm(self, noised_img):
    #     # NSM判别模块输出噪声图像的类别，输出值只有0和1，表示是否是Jpeg噪声图像
    #     return torch.round(torch.mean((torch.argmax(self.nsm_model(noised_img.clone().detach().clamp(-1,1)), dim=1)).float()))


    def train_val_decoder(self, noised_img, noise_choice):
        down = self.invDown(noised_img)                    # (B, 12, 64, 64)/(B, 12, 128, 128)
        cs_rev = self.cs_model(down, rev=True)              # (B, 24, 64, 64)/(B, 24, 128, 128)
        inv_back = self.invertible_model(cs_rev, rev=True)  # (B, 24, 64, 64)/(B, 24, 128, 128)
        img_fake, msg_fake = self.fusion_model(inv_back, None, self.invDown, rev=True)   # 都是(B, 12, 64, 64)/(B, 12, 128, 128)
        img_fake = self.invDown(img_fake, rev=True)         # (B, 3, 128, 128)/(B, 3, 256, 256)
        img_fake = img_fake.clamp(-1, 1)

        # img_fake：“恢复的载体图像”
        # msg_fake：通过可逆模块生成的“恢复的秘密信息”
        return img_fake, msg_fake

    def test_decoder(self, noised_img, predict_noiseType=None):
        # if predict_noiseType == 1:
        #     denoised_img = noised_img
        # else:
        #     denoised_img = self.enhance_model(noised_img)       # (B, 3, 128, 128)/(B, 3, 256, 256)

        down = self.invDown(noised_img)                      # (B, 12, 64, 64)/(B, 12, 128, 128)
        cs_rev = self.cs_model(down, rev=True)               # (B, 24, 64, 64)/(B, 24, 128, 128)
        inv_back = self.invertible_model(cs_rev, rev=True)   # (B, 24, 64, 64)/(B, 24, 128, 128)
        img_fake, msg_fake = self.fusion_model(inv_back, None, self.invDown, rev=True)   # 都是(B, 12, 64, 64)/(B, 12, 128, 128)
        img_fake = self.invDown(img_fake, rev=True)   # (B, 3, 128, 128)/(B, 3, 256, 256)
        img_fake = img_fake.clamp(-1, 1)

        return img_fake, msg_fake



class CIN(CINBasic):
    def __init__(self, opt, device):
        super(CIN, self).__init__(opt, device)

    def forward(self, image, msg, noise_choice, is_train=True):
        #
        if is_train:
            watermarking_img, loss_high = self.encoder(image, msg)
            noised_img = self.noise_pool(watermarking_img.clone(), image, noise_choice)

            # # 去噪，能提升载体图像和噪声图像之间的PSNR
            # if noise_choice == 'Identity' or noise_choice == 'Jpeg' or noise_choice == 'JpegTest':
            #     noised_img = noised_img
            # else:
            #     noised_img = self.enhance_model(noised_img)       # (B, 3, 128, 128)/(B, 3, 256, 256)

            img_fake, msg_fake = self.train_val_decoder(noised_img, noise_choice)
        #
        else:
            watermarking_img, loss_high = self.encoder(image, msg)
            noised_img = self.noise_pool(watermarking_img.clone(), image, noise_choice)

            # if noise_choice == 'Identity' or noise_choice == 'Jpeg' or noise_choice == 'JpegTest':
            if noise_choice == 'Identity':
                noised_img = noised_img
            else:
                # noised_img = noised_img
                noised_img = self.enhance_model(noised_img)  # (B, 3, 128, 128)/(B, 3, 256, 256)

            # predict_noiseType = self.nsm(noised_img)
            # print(predict_noiseType)
            img_fake, msg_fake = self.test_decoder(noised_img, predict_noiseType=None)

        # loss_high：高频小波损失
        # watermarking_img：水印图像
        # noised_img：噪声图像
        # img_fake：“恢复的载体图像”
        # msg_fake：通过可逆模块生成的“恢复的秘密信息”
        return loss_high, watermarking_img, noised_img, img_fake, msg_fake

