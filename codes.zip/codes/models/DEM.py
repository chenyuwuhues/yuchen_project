import torch
import torch.nn as nn
import math

class ConvTBNRelu(nn.Module):
    """
    A sequence of TConvolution, Batch Normalization, and ReLU activation
    转置卷积（TConvolution）、批量标准化（Batch Normalization）和 ReLU 激活函数。
    """

    def __init__(self, channels_in, channels_out, stride=2):
        super(ConvTBNRelu, self).__init__()

        self.layers = nn.Sequential(
            nn.ConvTranspose2d(channels_in, channels_out, kernel_size=2, stride=stride, padding=0),
            nn.BatchNorm2d(channels_out),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.layers(x)


class UpConvt(nn.Module):
    '''
    Network that composed by layers of ConvTBNRelu
    UpConvt是由多个 ConvTBNRelu 层组成的网络
    '''

    # blocks 表示要添加的 ConvTBNRelu 层的数量，跟通道数对应，为3
    def __init__(self, in_channels, out_channels, blocks):
        super(UpConvt, self).__init__()

        # 根据 blocks 参数的值决定是否添加一层起始的 ConvTBNRelu 层。
        # 如果 blocks 不为 0，则创建一个包含一层 ConvTBNRelu 的列表 layers，否则创建一个空列表。
        layers = [ConvTBNRelu(in_channels, out_channels)] if blocks != 0 else []
        for _ in range(blocks - 1):
            layer = ConvTBNRelu(out_channels, out_channels)
            layers.append(layer)

        self.layers = nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)


class DEM(nn.Module):
    def __init__(self, opt):
        super(DEM, self).__init__()
        #
        self.opt = opt
        self.batch_size = opt['train']['batch_size']    # 32
        self.msg_length = opt['network']['message_length']  # 30
        self.h, self.w = opt['network']['H'], opt['network']['W']   # 128,128
        '''
        down_opt: 
          use_down: true
          use_conv1x1: False
          in_nc: 3
          current_cn: 3
          down_num: 1          # 1  or  2
          scale: 0.5      
          type: haar
        '''
        down_opt = opt['network']['InvBlock']['downscaling']
        scale = pow(down_opt['scale'], down_opt['down_num'])    # 0.5^1
        self.scaled_h, self.scaled_w = int(opt['network']['H']*scale), int(opt['network']['W']*scale)   # 64,64
        self.diffusion_length = opt['network']['fusion']['fusion_length']  # 256
        blocks = opt['network']['fusion']['blocks']     # 3
        upconvT_channels = opt['network']['fusion']['upconvT_channels']     # 1

        # 定义全连接层，作用是将原始的水印长度进行扩展，即长度由30——>256
        self.linear1 = nn.Linear(opt['network']['message_length'], self.diffusion_length)
        self.linear2 = nn.Linear(opt['network']['message_length'], self.diffusion_length)
        self.linear3 = nn.Linear(opt['network']['message_length'], self.diffusion_length)
        self.reshape_length = int(math.sqrt(self.diffusion_length))  # 16

        # 定义上采样层，作用是将reshape之后的矩阵(大小为16*16，是由长度为256的一维向量得到，一维变二维)变成和载体图像一样的大小，即大小由16*16——>128*128
        self.UpConvt1 = UpConvt(upconvT_channels, upconvT_channels, blocks)
        self.UpConvt2 = UpConvt(upconvT_channels, upconvT_channels, blocks)
        self.UpConvt3 = UpConvt(upconvT_channels, upconvT_channels, blocks)

        # 定义反向的全连接层，作用是将经过reshape之后的水印（reshape：将128*128大小的二维矩阵水印变成长度为128*128=16384的一维水印）变成最开始的大小，也就是16374——>30
        self.linear_rev1 = nn.Linear(self.h*self.w, opt['network']['message_length'])
        self.linear_rev2 = nn.Linear(self.h*self.w, opt['network']['message_length'])
        self.linear_rev3 = nn.Linear(self.h*self.w, opt['network']['message_length'])

        #
        self.split1_img = opt['network']['InvBlock']['split1_img']  # 12
        self.repeat_num = opt['network']['InvBlock']['split2_repeat']   # 12


    def forward(self, image, message, haar, rev=False):
        if not rev:
            # 全连接层
            expanded_message1 = self.linear1(message)
            expanded_message2 = self.linear2(message)
            expanded_message3 = self.linear3(message)
            #
            expanded_message1 = torch.reshape(expanded_message1, (expanded_message1.size(0), 1, self.reshape_length, self.reshape_length))
            expanded_message2 = torch.reshape(expanded_message2, (expanded_message2.size(0), 1, self.reshape_length, self.reshape_length))
            expanded_message3 = torch.reshape(expanded_message3, (expanded_message3.size(0), 1, self.reshape_length, self.reshape_length))
            #
            expanded_message1 = self.UpConvt1(expanded_message1)  # [b 1 16 16] ->  [b 1 128 128] 
            expanded_message2 = self.UpConvt2(expanded_message2) 
            expanded_message3 = self.UpConvt3(expanded_message3) 
            #
            msg_concat = torch.cat([expanded_message1, expanded_message2, expanded_message3], dim=1)    # [b 3 128 128]
            msg_down = haar(msg_concat)     # 下采样得到[b 12 64 64]
            #
            concat = torch.cat([image, msg_down], dim=1)    # [b 24 64 64]

            return concat

        else:
            # image
            imgs = image[:, 0:self.split1_img, :, :]
            msg = image[:, self.split1_img:, :, :]
            msg = haar(msg, rev=True)
            #
            msg1 = msg[:, 0, :, :]
            msg2 = msg[:, 1, :, :]
            msg3 = msg[:, 2, :, :]
            msg1 = torch.reshape(msg1, (msg1.size(0), msg1.size(1) * msg1.size(2)))
            msg2 = torch.reshape(msg2, (msg2.size(0), msg2.size(1) * msg2.size(2)))
            msg3 = torch.reshape(msg3, (msg3.size(0), msg3.size(1) * msg3.size(2)))
            #
            msg1 = self.linear_rev1(msg1).clamp(-1, 1)
            msg2 = self.linear_rev2(msg2).clamp(-1, 1)
            msg3 = self.linear_rev3(msg3).clamp(-1, 1)
            # msg ave pooling
            msg_nms = torch.mean(torch.cat((msg1.unsqueeze(2), msg2.unsqueeze(2), msg3.unsqueeze(2)), dim=2), dim=2)
            
            return imgs, msg_nms




