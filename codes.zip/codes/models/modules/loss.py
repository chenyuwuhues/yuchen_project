import torch
import torch.nn as nn
import torchvision
import math
import torch
import torch.nn.functional as F
from torch.autograd import Variable
from math import exp




# -------------Reconstruction  img & msg  loss-----------------------------
class ReconstructionImgLoss(nn.Module):
    def __init__(self, opt, eps=1e-6):
        super(ReconstructionImgLoss, self).__init__()
        self.losstype = opt['loss']['type']['TypeRecImg']
        self.eps = eps
        self.N = opt['network']['input']['in_img_nc'] * opt["network"]['H'] * opt["network"]['W']

    def forward(self, true_img, fake_img):
        if self.losstype == 'l2':
            return torch.mean(torch.sum((fake_img - true_img)**2, (1, 2, 3))) / self.N 
        elif self.losstype == 'l1':
            diff = fake_img - true_img
            return torch.mean(torch.sum(torch.sqrt(diff * diff + self.eps), (1, 2, 3))) / self.N 
        else:
            print("reconstruction loss type error!")
            return 0


class ReconstructionMsgLoss(nn.Module):
    def __init__(self, opt):
        super(ReconstructionMsgLoss, self).__init__()
        self.losstype = opt['loss']['type']['TypeRecMsg']
        self.mse_loss = nn.MSELoss()
        self.bce_loss = nn.BCELoss()
        self.bce_logits_loss = nn.BCEWithLogitsLoss()

    def forward(self, messages, decoded_messages): 
        if self.losstype == 'mse':
            return self.mse_loss(messages, decoded_messages)
        elif self.losstype == 'bce':
            return self.bce_loss(messages, decoded_messages)
        elif self.losstype == 'bce_logits':
            return self.bce_logits_loss(messages, decoded_messages)
        else:
            print("ReconstructionMsgLoss loss type error!")
            return 0



# ------------------Encoded watermarked-image loss-------------------
class EncodedLoss(nn.Module):
    def __init__(self, opt, eps=1e-6):
        super(EncodedLoss, self).__init__()
        self.losstype = opt['loss']['type']['TypeEncoded']
        self.eps = eps
        self.N = opt['network']['input']['in_img_nc'] * opt["network"]['H'] * opt["network"]['W']

    def forward(self, true_img, watermarking_img):
        if self.losstype == 'l2':
            loss_mask = 1
            return torch.mean(torch.sum((loss_mask * watermarking_img - true_img)**2, (1, 2, 3))) / self.N
        elif self.losstype == 'l1':
            diff = watermarking_img - true_img
            return torch.mean(torch.sum(torch.sqrt(diff * diff + self.eps), (1, 2, 3))) / self.N 
        else:
            print("EncodedLoss loss type error!")
            return 0

# ------------------high loss-------------------
# 负责计算高频小波损失
# 让该损失越小则可以让水印尽量隐藏在原始图像的低频区域
class HighLoss(nn.Module):
    def __init__(self, opt, eps=1e-6):
        super(HighLoss, self).__init__()
        self.losstype = opt['loss']['type']['TypeHigh']
        self.eps = eps
        # 输入的载体图像、水印图像的高频信息这两者的大小都是(B, 9, 64, 64)，因此通道数*3，H和W都需要÷2
        self.N = (opt['network']['input']['in_img_nc']*3) * (opt["network"]['H']/2) * (opt["network"]['W']/2)

    def forward(self, cover_high, watermarking_high):
        if self.losstype == 'l2':
            loss_mask = 1
            return torch.mean(torch.sum((loss_mask * watermarking_high - cover_high)**2, (1, 2, 3))) / self.N
        elif self.losstype == 'l1':
            diff = watermarking_high - cover_high
            return torch.mean(torch.sum(torch.sqrt(diff * diff + self.eps), (1, 2, 3))) / self.N
        else:
            print("HighLoss loss type error!")
            return 0
