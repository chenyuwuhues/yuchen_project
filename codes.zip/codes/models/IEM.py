import torch
import torch.nn as nn
import numpy as np
from codes.models.modules.DWT_IWT import DWT_IWT

'''
    Image Enhancement Module模块: 
    对于不是JPEG压缩图像的噪声图像，使用小波降噪进行图像增强。
'''

class IEM(nn.Module):
    def __init__(self, opt, device):
        super(IEM, self).__init__()
        #
        self.opt = opt
        self.device = device


    def forward(self, noised_img):
        denoised_img = wavelet_denoise(noised_img)
        return denoised_img
        # return noised_img



'''
在代码中，只针对高频部分进行降噪，而不会影响到低频部分的水印信息，这样处理理论上来说能够对噪声图像进行正向增强
'''
# def wavelet_denoise(images):
#     dwt_iwt = DWT_IWT()
#     coeff = dwt_iwt(images)
#     LL = coeff.narrow(1, 0, 3)
#     HL = coeff.narrow(1, 3, 3)
#     LH = coeff.narrow(1, 6, 3)
#     HH = coeff.narrow(1, 9, 3)
#
#     # Sigmoid 函数会将小于阈值的系数映射到接近零的值，而不是直接置为零;
#     # 对于大于阈值的系数，Sigmoid 函数的值会接近于1，因此大于阈值的系数乘以接近于1的值，基本上保持不变。
#     def thresholding(HH, threshold):
#         return HH * torch.sigmoid(HH - threshold)
#
#
#     HH_thresholding = thresholding(HH, torch.std(HH) / 2)
#     catTensor = torch.cat((LL, HL, LH, HH_thresholding), dim=1)
#     denoised_images = dwt_iwt(catTensor, rev=True)
#     return denoised_images

def estimate_sigma(HH):
    """
    使用HH子带估计噪声标准差
    """
    sigma = torch.median(torch.abs(HH)) / 0.6745
    return sigma

def adaptive_thresholding(HH, sigma):
    """
    计算自适应阈值并对HH子带进行阈值处理
    """
    threshold = sigma**2 / torch.std(HH)
    HH_denoised = HH * torch.sigmoid(HH - threshold)
    return HH_denoised

def wavelet_denoise(images):
    dwt_iwt = DWT_IWT()
    coeff = dwt_iwt(images)
    LL = coeff.narrow(1, 0, 3)
    HL = coeff.narrow(1, 3, 3)
    LH = coeff.narrow(1, 6, 3)
    HH = coeff.narrow(1, 9, 3)

    # 估计噪声标准差
    sigma = estimate_sigma(HH)

    # 对HH子带进行自适应阈值处理
    HH_thresholding = adaptive_thresholding(HH, sigma)

    catTensor = torch.cat((LL, HL, LH, HH_thresholding), dim=1)
    denoised_images = dwt_iwt(catTensor, rev=True)
    return denoised_images