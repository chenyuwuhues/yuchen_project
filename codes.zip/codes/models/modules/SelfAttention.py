import math
import torch
from torch import nn

class ReduceSpatial(nn.Module):
    def __init__(self, input_channels, output_channels, kernel_size, stride, padding):
        super(ReduceSpatial, self).__init__()
        self.conv = nn.Conv2d(input_channels, output_channels, kernel_size, stride, padding)

    def forward(self, x):
        return self.conv(x)

class LayerNorm(nn.Module):
    def __init__(self, hidden_size, eps=1e-12):
        """Construct a layernorm module in the TF style (epsilon inside the square root).
        层归一化
        """
        super(LayerNorm, self).__init__()
        self.weight = nn.Parameter(torch.ones(hidden_size))     # 可训练的缩放参数，形状为 [hidden_size]，初始化为全1。
        self.bias = nn.Parameter(torch.zeros(hidden_size))      # 可训练的偏移参数，形状为 [hidden_size]，初始化为全0。
        self.variance_epsilon = eps                             # 一个小常数，用于避免除零错误，默认值为 1e-12。

    def forward(self, x):
        u = x.mean(-1, keepdim=True)                            # 计算输入 x 在最后一个维度上的均值。输入张量x，形状为 [batch_size, seq_len, hidden_size]。
        s = (x - u).pow(2).mean(-1, keepdim=True)               # 计算输入 x 的方差, 形状为 [batch_size, seq_len, 1]
        x = (x - u) / torch.sqrt(s + self.variance_epsilon)     # 对输入 x 进行归一化, 形状为 [batch_size, seq_len, 1]
        return self.weight * x + self.bias                      # 应用缩放和偏移，返回归一化后的张量, 形状为 [batch_size, seq_len, hidden_size]

class SelfAttention(nn.Module):
    '''
    num_attention_heads: 注意力头的数量。
    input_size: 输入张量的维度大小
    hidden_size: 输出张量的隐藏层维度大小
    hidden_dropout_prob: dropout 概率。
    '''
    def __init__(self, num_attention_heads, input_size, hidden_size, hidden_dropout_prob):
        super(SelfAttention, self).__init__()
        if hidden_size % num_attention_heads != 0:
            raise ValueError(
                "The hidden size (%d) is not a multiple of the number of attention "
                "heads (%d)" % (hidden_size, num_attention_heads))
        self.num_attention_heads = num_attention_heads
        self.attention_head_size = int(hidden_size / num_attention_heads)
        self.all_head_size = hidden_size

        self.query = nn.Linear(input_size, self.all_head_size)
        self.key = nn.Linear(input_size, self.all_head_size)
        self.value = nn.Linear(input_size, self.all_head_size)

        self.attn_dropout = nn.Dropout()

        # 做完self-attention 做一个前馈全连接 LayerNorm 输出
        self.dense = nn.Linear(hidden_size, hidden_size)
        self.LayerNorm = LayerNorm(hidden_size, eps=1e-12)
        self.out_dropout = nn.Dropout(hidden_dropout_prob)

    # 用于变换张量形状
    def transpose_for_scores(self, x):
        new_x_shape = x.size()[:-1] + (self.num_attention_heads, self.attention_head_size)
        x = x.view(*new_x_shape)
        return x.permute(0, 2, 1, 3)

    def forward(self, input_tensor):
        mixed_query_layer = self.query(input_tensor)
        mixed_key_layer = self.key(input_tensor)
        mixed_value_layer = self.value(input_tensor)

        query_layer = self.transpose_for_scores(mixed_query_layer)  # 形状为 [batch_size, num_attention_heads, seq_len, attention_head_size]
        key_layer = self.transpose_for_scores(mixed_key_layer)
        value_layer = self.transpose_for_scores(mixed_value_layer)

        # Take the dot product between "query" and "key" to get the raw attention scores.
        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))

        attention_scores = attention_scores / math.sqrt(self.attention_head_size)
        # Apply the attention mask is (precomputed for all layers in BertModel forward() function)
        # [batch_size heads seq_len seq_len] scores
        # [batch_size 1 1 seq_len]

        # attention_scores = attention_scores + attention_mask

        # Normalize the attention scores to probabilities.
        attention_probs = nn.Softmax(dim=-1)(attention_scores)
        # This is actually dropping out entire tokens to attend to, which might
        # seem a bit unusual, but is taken from the original Transformer paper.
        # Fixme
        attention_probs = self.attn_dropout(attention_probs)
        context_layer = torch.matmul(attention_probs, value_layer)
        context_layer = context_layer.permute(0, 2, 1, 3).contiguous()
        new_context_layer_shape = context_layer.size()[:-2] + (self.all_head_size,)
        context_layer = context_layer.view(*new_context_layer_shape)
        hidden_states = self.dense(context_layer)
        hidden_states = self.out_dropout(hidden_states)
        hidden_states = self.LayerNorm(hidden_states + input_tensor)

        return hidden_states

class CombineSpatialFrequency(nn.Module):
    def __init__(self, num_attention_heads, hidden_size, hidden_dropout_prob):
        super(CombineSpatialFrequency, self).__init__()
        self.spatial_reduction = ReduceSpatial(3, 12, kernel_size=3, stride=2, padding=1)
        self.self_attention = SelfAttention(num_attention_heads, 12, hidden_size, hidden_dropout_prob)

    def forward(self, spatial_features, frequency_features):
        # 降维空间域特征
        reduced_spatial_features = self.spatial_reduction(spatial_features)  # (B, 12, 64, 64)
        # 将空间域特征和频域特征reshape为 (B, 4096, 12)
        reduced_spatial_features = reduced_spatial_features.view(spatial_features.size(0), 12, -1).permute(0, 2, 1)
        frequency_features = frequency_features.view(frequency_features.size(0), 12, -1).permute(0, 2, 1)
        # 将空间域特征和频域特征相加
        combined_features = reduced_spatial_features + frequency_features
        # 应用注意力机制
        output = self.self_attention(combined_features)
        # reshape back to (B, 12, 64, 64)
        output = output.permute(0, 2, 1).view(spatial_features.size(0), 12, 64, 64)
        return output
